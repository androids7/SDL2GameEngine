/** Automatically generated file. DO NOT MODIFY */
package org.libsdl.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}